package com.reniec.reniec;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReniecApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReniecApplication.class, args);
	}

}
